package org.taitasciore.android.event;

/**
 * Created by roberto on 03/05/17.
 */

public class SendCountryEvent {

    public String country;

    public SendCountryEvent(String country) {
        this.country = country;
    }
}
