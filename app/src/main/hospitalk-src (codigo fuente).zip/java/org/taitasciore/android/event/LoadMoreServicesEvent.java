package org.taitasciore.android.event;

/**
 * Created by roberto on 29/04/17.
 */

public class LoadMoreServicesEvent {
}
