package org.taitasciore.android.model;

/**
 * Created by roberto on 19/04/17.
 */

public class ReviewResponse {

    private Review rating;

    public Review getRating() {
        return rating;
    }

    public void setRating(Review rating) {
        this.rating = rating;
    }
}
