package org.taitasciore.android.event;

/**
 * Created by roberto on 03/05/17.
 */

public class SendDeterminedLocationEvent {

    public boolean determined;

    public SendDeterminedLocationEvent(boolean determined) {
        this.determined = determined;
    }
}
