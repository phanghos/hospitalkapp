package org.taitasciore.android.event;

/**
 * Created by roberto on 19/04/17.
 */

public class RequestCityEvent {

}
