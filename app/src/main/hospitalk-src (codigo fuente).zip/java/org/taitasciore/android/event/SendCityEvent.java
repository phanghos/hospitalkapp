package org.taitasciore.android.event;

/**
 * Created by roberto on 19/04/17.
 */

public class SendCityEvent {

    public String city;

    public SendCityEvent(String city) {
        this.city = city;
    }
}
